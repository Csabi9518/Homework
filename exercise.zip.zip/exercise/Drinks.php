<head>
    <title>Menu - Kezdőlap </title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>

<body>
  <div class ="navbar">
    <ul>

    <li class="active"><a href="index.php">Home</a></li>
    <li><a href="Soups.php">Soups</a></li>
    <li><a href="Hamburger.php">Hamburgers</a></li>
    <li><a href="Pasta.php">Pasta</a></li>
    <li><a href="Pizza.php">Pizza</a></li>
    <li><a href="Desserts.php">Desserts</a></li>
    <li><a href="Drinks.php">Drinks</a></li>
    <li><a href="Gallery.php">Gallery page</a></li>
    <li><a href="contact.php">Contact page</a></li>
    <li><a href="lecture.php">Lecture page</a></li>
    </ul>
    </div>
    </body>
    
    

    <h2>Drinks</h2>
<h3>1</h3>
<p>Water 500Huf</p>
<h3>2</h3>
<p>Orange juice 500Huf</p>
<h3>3</h3>
<p>Coke 500Huf</p>
<h3>4</h3>
<p>Fanta 500Huf</p>
<h3>5</h3>
<p>Sprite 500Huf</p>
</div>
</div>
</body>
</html>
