<?php

?>
<head>
    <title>Menu - Kezdőlap </title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>

<body>
  <div class ="navbar">
    <ul>

    
    <li class="active"><a href="kezdolap.php">Home</a></li>
    <li><a>Soups</a></li>
    <li><a>Hamburgers</a></li>
    <li><a>Pasta</a></li>
    <li><a>Pizza</a></li>
    <li><a>Desserts</a></li>
    <li><a>Drinks</a></li>
    </ul>
    </div>
    </body> 
    </head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="login.php">Login</a></li>
            </ul>
        </nav>
    </header>
    <header>
        <nav>
            <ul>
                <li><a href="register.php">Registration</a></li>
            </ul>
        </nav>
    </header>

    <header>
        <nav>
            <ul>
            <img class="img-as1" src="img/as1.jpg" alt="as1"></a>
            </ul>
        </nav>
    </header>